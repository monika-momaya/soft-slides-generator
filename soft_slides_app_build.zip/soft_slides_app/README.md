
# Soft Slides Generator

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Notes
- Upload a flat template image.
- Upload an Excel with speaker name/title/company/role.
- Speaker photos should match speaker names by filename stem.
- The app exports PPTX and PNG downloads.
